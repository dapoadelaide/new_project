#!/bin/bash
#
# start
#

echo "ls -ltr:[/tmp/CMUTIL] before moving in & untarring CMUTIL.tar"
ls -ltr /tmp/CMUTIL 

cd /tmp/CMUTIL
echo "PWD:[`pwd`]"

#tar xvf CMUTIL.tar


ENV=$1
APPSRV_1OF4=$2
APPSRV_2OF4=$3
APPSRV_3OF4=$4
APPSRV_4OF4=$5
DBSRV_1OF1=$6
NODE_1OF2=$7
NODE_2OF2=$8
CFG_VARS="$9"

###################################

# AS1='mtb0122plmf5app.mcc.irs.gov'
# AS2='mtb0122plmf6app.mcc.irs.gov'
# AS3='mtb0122plmf7app.mcc.irs.gov'
# AS4='mtb0122plmf8app.mcc.irs.gov'
# OS1='vl2smtbappmf115.dstest.irsnet.gov'

# APP_SERVERS="-h $AS1 -h $AS2 -h $AS3 -h $AS4"
# DB_SERVERS="-h $OS1"
# WAS_DMS="-h $AS1 -h $AS3"
# WAS_NODE1=CustomNode22plmf5app
# WAS_NODE2=CustomNode22plmf6app

# Build *.servers.lis
#
echo "AS1='$2'" >${1}_servers.lis
echo "AS2='$3'" >>${1}_servers.lis
echo "AS3='$4'" >>${1}_servers.lis
echo "AS4='$5'" >>${1}_servers.lis
echo "OS1='$6'" >>${1}_servers.lis

echo "">>${1}_servers.lis

echo "APP_SERVERS=\"-h \$AS1 -h \$AS2 -h \$AS3 -h \$AS4\"" >>${1}_servers.lis
echo "DB_SERVERS=\"-h \$OS1\"" >>${1}_servers.lis
echo "WAS_DMS=\"-h \$AS1 -h \$AS3\"" >>${1}_servers.lis
echo "WAS_NODE1=$7" >>${1}_servers.lis
echo "WAS_NODE2=$8" >>${1}_servers.lis

###################################

# ms00486=PETE
# ms00500=PETE
# ms00488=PETE
# ms00489=PETE
# ms00570a=PETE
# vl1smtboramef02=PETE

# Build ENVLIST 
#
echo "$2=${1}" >ENVLIST
echo "$3=${1}" >>ENVLIST
echo "$4=${1}" >>ENVLIST
echo "$5=${1}" >>ENVLIST
echo "$6=${1}" >>ENVLIST

###################################

echo ""

# Verify contents of files created
#
echo "[${1}_servers.lis] after built"
echo "=============================="
cat ${1}_servers.lis
echo ""
echo "[ENVLIST] after built"
echo "====================="
cat ENVLIST
echo ""

#================================
# chmod 644 $log
#================================

# do GENERATE script
echo ""
 echo   "./gen_mef_archive.sh [$CFG_VARS]"
 # ./gen_mef_archive.sh $CFG_VARS
 echo " ./gen_mef_archive.sh $CFG_VARS "

exit 
