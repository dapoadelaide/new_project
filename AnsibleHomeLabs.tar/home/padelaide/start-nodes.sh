#!/bin/bash
task="start-nodes"

# start
#
date
pwd
id
hostname
#
echo ""
echo "*** Running [su - wasadmin -c '/opt/IBM/WebSphere855/AppServer/scripts/mef_node_ctl.sh /opt/IBM/WebSphere855/AppServer start WAS855'] ***"
su - wasadmin -c "/opt/IBM/WebSphere855/AppServer/scripts/mef_node_ctl.sh /opt/IBM/WebSphere855/AppServer start WAS855"
echo "Return Code for [su - wasadmin -c '/opt/IBM/WebSphere855/AppServer/scripts/mef_node_ctl.sh /opt/IBM/WebSphere855/AppServer start WAS855']:[$?]"

echo ""

