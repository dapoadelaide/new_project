#!/bin/bash

script="`basename $0`" 
log="/tmp/${script}.`date '+%m%d%Y-%H%M%S'`.logfile"

pipe1="/tmp/regular_pipe.$$"
pipe2="/tmp/error_pipe.$$"
trap 'rm "$pipe1" "$pipe2"' EXIT
 

mkfifo "$pipe1"
mkfifo "$pipe2"

tee -a $log < "$pipe1" &
tee -a $log >&2 < "$pipe2" &
 

# Redirect output to a logfile as well as their normal locations

 exec >"$pipe1"
 exec 2>"$pipe2"




echo "==================" 
echo "==================" 
echo "==================" 
echo "==================" 
echo "==================" 
echo "==================" 
echo "==================" 




echo "==================" > /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out

echo "$script---- $1 ---- $2 ---- $3" >>/tmp/me.out
echo "==================" >> /tmp/me.out
echo "hello `hostname`" >> /tmp/me.out

echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out
echo "==================" >> /tmp/me.out

echo "PWD->>>:$PWD" >> /tmp/me.out
echo "pwd->>>:`pwd`" >> /tmp/me.out

echo " `env`" >>/tmp/me.out

exit

