#!/bin/bash
task="start-dmgr"

# start
date
pwd
id
hostname
#
echo ""
echo "*** Running [su - wasadmin -c '/opt/IBM/WebSphere855/AppServer/scripts/mef_dmgr_ctl.sh  /opt/IBM/WebSphere855/AppServer MEFBWAS-855-Dmgr01 start WAS855'] ***"

thisHost=`hostname`
echo "thisHost: $thisHost"

if [[ "$thisHost" == *"Adam"* ]] || [[ "$thisHost" == *"cent7"* ]] ; then
  echo "BYPASSED: [host: $thisHost] does not qualify to run [$task], exiting script..."
  exit
fi

su - wasadmin -c "/opt/IBM/WebSphere855/AppServer/scripts/mef_dmgr_ctl.sh /opt/IBM/WebSphere855/AppServer MEFBWAS-855-Dmgr01 start WAS855"

echo "Return Code for [su - wasadmin -c '/opt/IBM/WebSphere855/AppServer/scripts/mef_dmgr_ctl.sh  /opt/IBM/WebSphere855/AppServer MEFBWAS-855-Dmgr01 start WAS855']:[$?]"
echo ""
